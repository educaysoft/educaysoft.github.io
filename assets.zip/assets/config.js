// cpanel - site_templates/vcard_dev/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        phone: "0997919650",
        fax: "",
        email: "educaysoft@gmail.com",
        address: "educaysoft@educaysoft.com",
        social: [
            
            {
                icon: 'facebook',
                link: "https:\/\/www.facebook.com\/stalin.francis.7\/"
            },
            
            
            {
                icon: 'twitter',
                link: "https:\/\/twitter.com\/educaysoft1"
            },
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
        accent: ""
    },
    slides: [
        {
            prefix: "Ing.",
            title: "Stalin Francis  MSc.",
            subtitle: "ESPOL: Magister en Computer Science",
            type: 'vcard',
            backgroundImage: "",
            backgroundColor: "",
            color: "",
            buttonText: "Mi empresa",
            buttonLink: "http:\/\/educaysoft.org\/wp\/",
            biography: "Donaciones:",
            portraitImage: "\/assets\/images\/educaysoft\/StalinUtelvt.png"
        }
    ]
};
lvt.png"
        }
    ]
};
